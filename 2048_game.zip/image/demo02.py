# # 全局变量
# list_merge = [2,0,2,0]
# (1). 定义函数,将零元素移动到末尾zero_to_end()
#  备注：操作全局变量
#     [2,0,2,0]  -->  [2,2,0,0]
#     [2,0,0,2]  -->  [2,2,0,0]
#     [2,4,0,2]  -->  [2,4,2,0]
# (2). 定义合并函数(向左移动的核心算法)　merge()
#     思路：相邻相同数据合并
#     [2,0,2,0]  -->[2,2,0,0]  -->  [4,0,0,0]
#     [2,0,0,2]  -->[2,2,0,0]  -->  [4,0,0,0]
#     [4,4,4,4]  -->  [8,8,0,0]
#     [2,0,4,2]  -->  [2,4,2,0]
list_merge = [2, 0, 0, 2]

def zeor_move(line):
    for i in range(len(line) - 1, -1, -1):
        if line[i] == 0:
            del line[i]
            line.append(0)
def pt():
    for item in map:   
        print(item)
def merge(line):
    zeor_move(line)
    for i in range(len(line) - 1):
        if line[i] == line[i + 1]:
            del line[i + 1]
            line[i] *= 2
            line.append(0)


map = [[2, 8, 8, 2],
       [2, 0, 0, 2],
       [4, 4, 4, 4],
       [2, 0, 4, 2]]
def move_left(map):
    """
        向左移动map
        思想：获取每行，交给list_merge，在通知merge()进行合并
    :return:
    """

    for line in map:
        merge(line)
for item in map:
    print(item)



def move_right(map):
    """
        向右移动map
        思想：获取每行，翻转后交给list_merge，在通知merge()进行合并，最后还原给map
    :return:
    """
    for line in map:
        # 从右向左获取数据形成新列表
        list_merge = line[::-1]
        # 处理数据
        merge(list_merge)
        # 将处理后的数据再从右向左还给map
        line[::-1] = list_merge

#move_right(map)






# 转置
def square_matrix_transposition(map):
    """
        方阵转置（列转换为行）

    """
    for c in range(1, len(map)):  # 1 2 3
        for r in range(c, len(map)):
            map[r][c - 1], map[c - 1][r] = map[c - 1][r], map[r][c - 1]



print("*"*30)
move_left(map)
pt()