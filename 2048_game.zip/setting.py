import pygame

list = []
for i in range(257):
    list.append(i)


class Setting():
    def __init__(self):
        self.map = [
            [0, 2, 2, 0],
            [0, 2, 0, 2],
            [2, 0, 2, 4],
            [0, 0, 0, 0],
        ]

        self.bg_color = (130, 130, 130)
        self.number_list = list
        # self.number_list=["image/0.png","image/1.png","image/2.png","image/3.png","image/4.png","image/5.png","image/6.png","image/7.png","image/8.png","image/9.png"]
        self.number_list[0] = "image/null.png"
        self.number_list[2] = "image/2.png"
        self.number_list[4] = "image/4.png"
        self.number_list[8] = "image/8.png"
        self.number_list[16] = "image/16.png"
        self.number_list[32] = "image/32.png"
        self.number_list[64] = "image/64.png"
        self.number_list[128] = "image/128.png"
        self.number_list[256] = "image/256.png"
        # 屏幕 棋盘大小
        self.screen_rect = (800, 600)
        self.map_rect = (400, 400)
        self.map_local = (200, 100)

        # 绘制棋盘
        self.screen_background = pygame.image.load("image/bg2.png")
        self.screen_background = pygame.transform.scale(self.screen_background, self.map_rect)
