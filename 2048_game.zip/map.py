import pygame
import pygame.font
from pygame.sprite import Sprite
class Map1(Sprite):
    def __init__(self,setting,screen,i,list_i,list_j):
        super(Map1, self).__init__()
        self.screen = screen
        self.setting=setting
        # 加载数字
        self.image = pygame.image.load(setting.number_list[i])
        # 修改图片大小！！！！！！！！！！
        self.image = pygame.transform.scale(self.image, (70, 70))
        self.rect = self.image.get_rect()

        # 初始化宝石属性，位置
        self.level = 1
        self.rect.right =285+100*list_j
        self.rect.bottom =185+100*list_i