#!/usr/bin/python3
import pygame
from setting import Setting
from pygame.sprite import Group
import game_function2 as gf
import copy
path='/home/tarena/zyq/air_war/2048game'
def run():
    clock = pygame.time.Clock()
    pygame.init()
    setting=Setting()
    screen=pygame.display.set_mode(setting.screen_rect)
    pygame.display.set_caption("2048")
    #绘制数字
    maps=Group()
    gf.create_map(setting, screen,maps,setting.map)
    #开始游戏的主循环:
    while True:
        map_copy=copy.deepcopy(setting.map)
        #监视事件和鼠标事件
        gf.check_event(setting,maps,screen, map_copy)
        #绘制屏幕
        gf.update_screen(screen,setting,maps)






if __name__ == '__main__':
    run()