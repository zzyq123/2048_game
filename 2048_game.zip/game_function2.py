import sys
import pygame
from map import Map1
import time
import random
def create_map(setting, screen,maps,list_maps):
    #生成数字
    for maps_numberi in range(len(list_maps)):
        for maps_numberj in range(len(list_maps)):
            i=list_maps[maps_numberi][maps_numberj]
            map = Map1(setting,screen,i,maps_numberi,maps_numberj)
            maps.add(map)

def create_2(setting):
    while True:
        list_i=random.randint(0,3)
        list_j=random.randint(0,3)
        if setting.map[list_j][list_j]==0:
            setting.map[list_j][list_j] =2
            break



def check_event(setting,maps,screen, map_copy):
    #事件监听
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        #按键检测
        elif event.type == pygame.KEYDOWN:
            if  event.key == pygame.K_LEFT:
                move_left(setting.map)
                if setting.map!= map_copy:
                    create_2(setting)
                reprotract_map(setting, screen, maps)



            if event.key == pygame.K_RIGHT:
                move_right(setting.map)
                if setting.map != map_copy:
                    create_2(setting)
                reprotract_map(setting, screen, maps)


            if event.key == pygame.K_UP:
                move_up(setting.map)
                if setting.map != map_copy:
                    create_2(setting)
                reprotract_map(setting, screen, maps)

            if event.key == pygame.K_DOWN:
                move_down(setting.map)
                if setting.map != map_copy:
                    create_2(setting)
                reprotract_map(setting, screen, maps)


def reprotract_map(setting,screen,maps):
    maps.empty()
    create_map(setting, screen, maps, setting.map)
    maps.draw(screen)


def zeor_move(line):
    #0向后移动
    for i in range(len(line) - 1, -1, -1):
        if line[i] == 0:
            del line[i]
            line.append(0)

def merge(line):
    #行向左移动
    zeor_move(line)
    for i in range(len(line) - 1):
        if line[i] == line[i + 1]:
            del line[i + 1]
            line[i] *= 2
            line.append(0)


def square_matrix_transposition(map):
    """
        方阵转置（列转换为行）

    """
    for c in range(1, len(map)):  # 1 2 3
        for r in range(c, len(map)):
            map[r][c - 1], map[c - 1][r] = map[c - 1][r], map[r][c - 1]
def move_left(map):
    #整体向左移动
    for line in map:
        merge(line)

def move_right(map):
    """
        向右移动map
        思想：获取每行，翻转后交给list_merge，
    """
    for line in map:
        # 从右向左获取数据形成新列表
        list_merge = line[::-1]
        # 处理数据
        merge(list_merge)
        # 将处理后的数据再从右向左还给map
        line[::-1] = list_merge


def move_up(map):
    """
        向上移动
        思想：  转置  move_left　转置　
    """
    square_matrix_transposition(map)
    move_left(map)
    square_matrix_transposition(map)



def move_down(map):
    """
        向下移动
        思想: 转置  move_right　转置
    :return:
    """
    square_matrix_transposition(map)
    move_right(map)
    square_matrix_transposition(map)


def update_screen(screen,setting,maps):
    screen.fill(setting.bg_color)
    screen.blit(setting.screen_background, setting.map_local)
    maps.draw(screen)
    pygame.display.flip()